class MTLParams():
    dim_cls_linear: int
    num_labels: int
    dim_exp_gru: int